package com.sorting.AdvancedSorting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedSortingApplicationTests {

	@Test
	void contextLoads() {
	}

}
